package org.step_it.components;

public class Product {

}
